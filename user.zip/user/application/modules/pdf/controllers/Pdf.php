<?php defined("BASEPATH") OR exit("No direct script access allowed");

class Pdf extends CI_Controller {

  function __construct() {
    parent::__construct();

      $this->load->model('pdfs');
  }

  /**
     * This function is used to load page view
     * @return Void
     */


    public function index()
    {
        error_reporting(E_ALL); ini_set('display_errors', 1) ;
        is_login();
        if(CheckPermission("users", "own_read")){
            $result =  $this->pdfs->all();
        } else {
            $result =  $this->pdfs->user_pdfs();
        }

        $this->load->view('include/header');
        $this->load->view('index', compact('result'));
        $this->load->view('include/footer');
    }
}
?>