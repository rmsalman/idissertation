<!-- page content -->
 <!-- Content Wrapper. Contains page content -->

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap.min.js"></script>
  <div class="content-wrapper settingPage">
    <!-- Main content -->
    <section class="content">
      <!-- Default box -->
      <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">PDFs </h3>
        </div>
        <div class="box-body">
          <div class="row">
            <div class="col-lg-12">
              <div class="col-md-6 col-md-offset-1 aboutshift">
                  <div class="container">
                      <div class="table-responsive">
                          <table class="table table-bordered table-hover table-condensed  data-table ">
                              <thead>
                                  <tr>
                                      <th>ID</th>
                                      <th>Name</th>
                                      <th>Last Name</th>
                                      <th>Email</th>
                                      <th>Phone</th>
                                      <th>Address</th>
                                      <th>Address 2</th>
                                      <th>Zip</th>
                                      <th>inst.</th>
                                      <th>Black and White Pages</th>
                                      <th>Colour Pages</th>
                                      <th>Number of copies</th>
                                      <th>Number of pages</th>
                                      <th>Total Printing Cost</th>

                                      <th>Black and White Pages</th>
                                      <th>Colour Pages</th>
                                      <th>Number of copies</th>
                                      <th>Turnitn Report Total Cost</th>

                                      <th>Binding Cover</th>
                                      <th>Number of copies</th>
                                      <th>Number of pages</th>
                                      <th>Front and Spine Hotfoil Letters £3</th>
                                      <th>Total Binding Cost</th>

                                      <th>CD</th>
                                      <th>CD Poket</th>
                                      <th>Turnitin Report Sleeve</th>
                                      <th>Total Extra(s) Cost</th>
                                      <th>Total Cost</th>
                                      <th>file</th>
                                      <th>t_file</th>
                                      <th>created</th>
                                      <th>Pay</th>
                                  </tr>
                              </thead>
                              <tbody>
                              <?php

                              if (isset($result) && !empty($result)) {
                                  foreach ($result as $row) {
                                      ?>
                                      <tr>
                                          <td><?= $row->id ?></td>
                                          <td><?= $row->name; ?></td>
                                          <td><?= $row->lname; ?></td>
                                          <td><?= $row->email; ?></td>
                                          <td><?= $row->cell; ?></td>
                                          <td><?= $row->address; ?></td>
                                          <td><?= $row->inst; ?></td>
                                          <td><?= $row->p_BW; ?></td>
                                          <td><?= $row->p_clr; ?></td>
                                          <td><?= $row->p_copies; ?></td>

                                          <td><?= $row->p_pages; ?></td>
                                          <td><?= $row->p_total; ?></td>

                                          <td><?= $row->t_BW; ?></td>
                                          <td><?= $row->t_clr; ?></td>
                                          <td><?= $row->t_copies; ?></td>

                                          <td><?= $row->t_pages; ?></td>
                                          <td><?= $row->t_total; ?></td>

                                          <td><?= $row->b_bin; ?></td>
                                          <td><?= $row->b_copies; ?></td>
                                          <td><?= $row->b_true; ?></td>
                                          <td><?= $row->b_total; ?></td>

                                          <td><?= $row->e_cd; ?></td>
                                          <td><?= $row->e_cdp; ?></td>
                                          <td><?= $row->e_tr; ?></td>
                                          <td><?= $row->e_total; ?></td>
                                          <td><?= $row->grand_total; ?></td>
                                          <td><a href="/uploads<?= $row->file; ?>" target="_blank"><?= $row->file; ?></a></td>
                                          <td><a href="/uploads<?= $row->file2; ?>" target="_blank"><?= $row->file2; ?></a></td>
                                          <td><?= $row->created; ?></td>
                                          <td><form action="https://secure-test.worldpay.com/wcc/purchase" method="POST">
                                                  <input type="hidden" name="testMode" value="100">
                                                  <input type="hidden" name="instId" value="1233012">
                                                  <input type="hidden" name="cartId" value="<?= $row->id; ?>">
                                                  <input type="hidden" name="amount" value="<?= str_replace("£ ","", $row->grand_total); ?>">
                                                  <input type="hidden" name="currency" value="GBP">
                                                  <input type="submit" value=" Pay Here " class="btn btn-success btn-block">
                                              </form></td>
                                      </tr>
                                      <?php
                                  }
                              } else {
                                  echo "<td colspan=23><center>No Results Found</center></td>";
                              }
                              ?>

                              </tbody>
                          </table>
                      </div>
                  </div>
                  <br>



                  <br>
              </div>
                <script>
                    $(document).ready(function() {
                        $('.data-table').DataTable();
                    } );
                </script>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
    <!-- /.box -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->